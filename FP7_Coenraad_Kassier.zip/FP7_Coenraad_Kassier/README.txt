This program formats output located in a powerpoint slide.
There are 3 output formats that can be selected in the terminal as text.

The options are:

Option 2: (portrait)

Image on the right side (on a separate page).

Text on the left side (on a separate page)

Option 3: (portrait)

Text at the top

Image at the bottom